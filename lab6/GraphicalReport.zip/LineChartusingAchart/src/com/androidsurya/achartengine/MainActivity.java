package com.androidsurya.achartengine;

import org.achartengine.ChartFactory;
import org.achartengine.chart.PointStyle;
import org.achartengine.model.XYMultipleSeriesDataset;
import org.achartengine.model.XYSeries;
import org.achartengine.renderer.XYMultipleSeriesRenderer;
import org.achartengine.renderer.XYSeriesRenderer;
import android.app.Activity;
import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;

public class MainActivity extends Activity {
	
	private String[] time = new String[] {
				"10AM", "12PM" , "3PM", "6PM", "10PM", "1AM",
			};

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        openChart();
    }    
    private void openChart(){
    	int[] x = { 1,2,3,4,5};
    	int[] left = { 12,1,14,6,20};
    	int[] right = {20, 5, 9, 21, 7};
    	int[] top = {5,19,21,5,4};
    	
    	// Creating an  XYSeries for Income
    	XYSeries leftSeries = new XYSeries("Left Gesture");
    	// Creating an  XYSeries for Income
    	XYSeries rightSeries = new XYSeries("Right Gesture");
    	
    	//Creating an  XYSeries for fun
    	XYSeries topSeries = new XYSeries("Top Gesture");
    	// Adding data to Income and Expense Series
    	for(int i=0;i<x.length;i++){
    		leftSeries.add(x[i], left[i]);
    		rightSeries.add(x[i],right[i]);
    		topSeries.add(x[i],top[i]);
    	}
    	
    	// Creating a dataset to hold each series
    	XYMultipleSeriesDataset dataset = new XYMultipleSeriesDataset();
    	// Adding Income Series to the dataset
    	dataset.addSeries(leftSeries);
    	// Adding Expense Series to dataset
    	dataset.addSeries(rightSeries);    
    	dataset.addSeries(topSeries);
    	
    	
    	// Creating XYSeriesRenderer to customize incomeSeries
    	XYSeriesRenderer leftRenderer = new XYSeriesRenderer();
    	leftRenderer.setColor(Color.WHITE);
    	leftRenderer.setPointStyle(PointStyle.CIRCLE);
    	leftRenderer.setFillPoints(true);
    	leftRenderer.setLineWidth(2);
    	leftRenderer.setDisplayChartValues(true);
    	
    	// Creating XYSeriesRenderer to customize expenseSeries
    	XYSeriesRenderer rightRenderer = new XYSeriesRenderer();
    	rightRenderer.setColor(Color.GREEN);
    	rightRenderer.setPointStyle(PointStyle.CIRCLE);
    	rightRenderer.setFillPoints(true);
    	rightRenderer.setLineWidth(3);
    	rightRenderer.setDisplayChartValues(true);
    	
    	

    	// Creating XYSeriesRenderer to customize incomeSeries
    	XYSeriesRenderer topRenderer = new XYSeriesRenderer();
    	topRenderer.setColor(Color.RED);
    	topRenderer.setPointStyle(PointStyle.CIRCLE);
    	topRenderer.setFillPoints(true);
    	topRenderer.setLineWidth(4);
    	topRenderer.setDisplayChartValues(true);
    	
    	// Creating a XYMultipleSeriesRenderer to customize the whole chart
    	XYMultipleSeriesRenderer multiRenderer = new XYMultipleSeriesRenderer();
    	multiRenderer.setXLabels(0);
    	multiRenderer.setChartTitle("Comparison between different gestures");
    	multiRenderer.setXTitle("Time");
    	multiRenderer.setYTitle("Count");
    	multiRenderer.setZoomButtonsVisible(true);    	    	
    	for(int i=0;i<x.length;i++){
    		multiRenderer.addXTextLabel(i+1, time[i]);    		
    	}    	
    	
    	// Adding incomeRenderer and expenseRenderer to multipleRenderer
    	// Note: The order of adding dataseries to dataset and renderers to multipleRenderer
    	// should be same
    	multiRenderer.addSeriesRenderer(leftRenderer);
    	multiRenderer.addSeriesRenderer(rightRenderer);
    	multiRenderer.addSeriesRenderer(topRenderer);
    	
    	// Creating an intent to plot line chart using dataset and multipleRenderer
    	Intent intent = ChartFactory.getLineChartIntent(getBaseContext(), dataset, multiRenderer);
    	
    	// Start Activity
    	startActivity(intent);
    	
    }

 
}