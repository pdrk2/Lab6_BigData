/** Automatically generated file. DO NOT MODIFY */
package com.androidsurya.achartengine;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}